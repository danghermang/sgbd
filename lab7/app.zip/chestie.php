<?php
$conn=oci_connect('student','STUDENT','localhost/XE');
if(!$conn)
    echo 'noooo';
echo ('connection succesfull');
echo "<br>";
$standardid= $_REQUEST["id"];
echo "   id=".$standardid;
echo "<br>";
//$array = oci_parse($conn,'SELECT to_char(question),to_char(answer) FROM QUESTIONS where id='.$standardid);
$array = oci_parse($conn,'SELECT to_char(question),to_char(answer),count(question) FROM QUESTIONS where id=:standardid group by to_char(question),to_char(answer)');
oci_bind_by_name($array,':standardid',$standardid);
$r = oci_execute($array);
if(!$r)
    echo "Intrebarea nu exista";
else
{
print '<table border="1">';
while ($row = oci_fetch_array($array, OCI_RETURN_NULLS+OCI_ASSOC)) {
   print '<tr>';
    if(!$row)
    {echo "Intrebarea nu exista";
        break;
    }
   foreach ($row as $item) {
       
           print '<td>'.($item !== null ? htmlentities($item, ENT_QUOTES) : '&nbsp').'</td>';
   }
   print '</tr>';
}
print '</table>';
}
// Close connection 
oci_close($conn);
?>